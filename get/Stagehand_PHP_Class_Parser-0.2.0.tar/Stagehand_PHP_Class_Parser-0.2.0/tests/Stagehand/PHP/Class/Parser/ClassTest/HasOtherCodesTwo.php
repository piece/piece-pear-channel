<?php
$a = 10;

class Stagehand_PHP_Class_Parser_ClassTest_HasOtherCodesTwo_Foo
{
}

$b = 20;

class Stagehand_PHP_Class_Parser_ClassTest_HasOtherCodesTwo_Bar
{
}

$c = 30;

class Stagehand_PHP_Class_Parser_ClassTest_HasOtherCodesTwo_Baz
{
}

$d = 40;
