<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

/**
 * PHP versions 4 and 5
 *
 * Copyright (c) 2007 KUBO Atsuhiro <iteman@users.sourceforge.net>,
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    Piece_ORM
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    SVN: $Id: Generator.php 98 2007-03-06 18:23:23Z iteman $
 * @link       http://piece-framework.com/piece-orm/
 * @since      File available since Release 0.1.0
 */

require_once 'Piece/ORM/Inflector.php';

// {{{ Piece_ORM_Mapper_Generator

/**
 * The source code generator which generates a mapper source based on
 * a given configuration.
 *
 * @package    Piece_ORM
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    Release: 0.1.0
 * @link       http://piece-framework.com/piece-orm/
 * @since      Class available since Release 0.1.0
 */
class Piece_ORM_Mapper_Generator
{

    // {{{ properties

    /**#@+
     * @access public
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    var $_mapperClass;
    var $_mapperName;
    var $_config;
    var $_metadata;
    var $_methodDefinitions = array();

    /**#@-*/

    /**#@+
     * @access public
     */

    // }}}
    // {{{ constructor

    /**
     * Initializes the properties with the arguments.
     *
     * @param string             $mapperClass
     * @param string             $mapperName
     * @param array              $config
     * @param Piece_ORM_Metadata &$metadata
     */
    function Piece_ORM_Mapper_Generator($mapperClass, $mapperName, $config, &$metadata)
    {
        $this->_mapperClass = $mapperClass;
        $this->_mapperName  = $mapperName;
        $this->_config      = $config;
        $this->_metadata    = &$metadata;
    }

    // }}}
    // {{{ generate()

    /**
     * Generates a mapper source.
     *
     * @return string
     */
    function generate()
    {
        $this->_generateFind();
        $this->_generateInsert();
        $this->_generateDelete();
        $this->_generateUpdate();
        $this->_generateFromConfiguration();

        return "class {$this->_mapperClass} extends Piece_ORM_Mapper_Common
{" . implode("\n", $this->_methodDefinitions) . "\n}";
    }

    /**#@-*/

    /**#@+
     * @access private
     */

    // }}}
    // {{{ _addFindBy()

    /**
     * Adds a findByXXX method and its query to the mapper source.
     *
     * @param string $methodName
     * @param string $query
     */
    function _addFindBy($methodName, $query)
    {
        $propertyName = strtolower($methodName);
        $this->_methodDefinitions[$methodName] = "
    var \${$propertyName} = '$query';
    function &$methodName(\$criteria)
    {
        \$object = &\$this->_find(__FUNCTION__, \$criteria);
        return \$object;
    }";
    }

    // }}}
    // {{{ _addInsert()

    /**
     * Adds the query for insert() to the mapper source.
     *
     * @param string $query
     */
    function _addInsert($query)
    {
        $this->_methodDefinitions['insert'] = "
    var \$insert = '$query';";
    }

    // }}}
    // {{{ _addFindAll()

    /**
     * Adds the query for findAll() to the mapper source.
     *
     * @param string $query
     */
    function _addFindAll($query)
    {
        $this->_methodDefinitions['findall'] = "
    var \$findall = '$query';";
    }

    // }}}
    // {{{ _addFindAllBy()

    /**
     * Adds a findAllByXXX method and its query to the mapper source.
     *
     * @param string $methodName
     * @param string $query
     */
    function _addFindAllBy($methodName, $query)
    {
        $propertyName = strtolower($methodName);
        $this->_methodDefinitions[$methodName] = "
    var \${$propertyName} = '$query';
    function $methodName(\$criteria)
    {
        \$objects = \$this->_findAll(__FUNCTION__, \$criteria);
        return \$objects;
    }";
    }

    // }}}
    // {{{ _generateFromConfigration()

    /**
     * Generates methods from configuration.
     */
    function _generateFromConfiguration()
    {
        foreach ($this->_config['method'] as $method) {
            if (preg_match('/^findBy.+$/i', $method['name'])) {
                $this->_addFindBy($method['name'], $method['query']);
            } elseif (preg_match('/^findAll$/i', $method['name'])) {
                $this->_addFindAll($method['query']);
            } elseif (preg_match('/^findAllBy.+$/i', $method['name'])) {
                $this->_addFindAllBy($method['name'], $method['query']);
            } elseif (preg_match('/^insert$/i', $method['name'])) {
                $this->_addInsert($method['query']);
            } elseif (preg_match('/^update$/i', $method['name'])) {
                $this->_addUpdate($method['query']);
            } elseif (preg_match('/^delete$/i', $method['name'])) {
                $this->_addDelete($method['query']);
            }
        }
    }

    // }}}
    // {{{ _generateFind()

    /**
     * Generates built-in findByXXX, findAll, findAllByXXX methods.
     */
    function _generateFind()
    {
        foreach ($this->_metadata->getFieldNames() as $fieldName) {
            $datatype = $this->_metadata->getDatatype($fieldName);
            if ($datatype == 'integer' || $datatype == 'text') {
                
                $camelizedFieldName = Piece_ORM_Inflector::camelize($fieldName);
                $this->_addFindBy("findBy$camelizedFieldName", 'SELECT * FROM ' . $this->_metadata->getTableName() . " WHERE $fieldName = \$" . Piece_ORM_Inflector::lowerCaseFirstLetter($camelizedFieldName));
                $this->_addFindAllBy("findAllBy$camelizedFieldName", 'SELECT * FROM ' . $this->_metadata->getTableName() . " WHERE $fieldName = \$" . Piece_ORM_Inflector::lowerCaseFirstLetter($camelizedFieldName));
            }
        }

        $this->_addFindAll('SELECT * FROM ' . $this->_metadata->getTableName());
    }

    // }}}
    // {{{ _generateInsert()

    /**
     * Generates the built-in insert method.
     */
    function _generateInsert()
    {
        $fields = array();
        foreach ($this->_metadata->getFieldNames() as $fieldName) {
            $default = $this->_metadata->getDefault($fieldName);
            if (is_null($default) || !strlen($default)) {
                if (!$this->_metadata->isAutoIncrement($fieldName)) {
                    $fields[] = $fieldName;
                }
            }
        }

        $this->_addInsert('INSERT INTO ' . $this->_metadata->getTableName() . ' (' . implode(", ", $fields) . ') VALUES (' . implode(', ', array_map(create_function('$f', "return '\$' . Piece_ORM_Inflector::camelize(\$f, true);"), $fields)) . ')');
    }

    // }}}
    // {{{ _generateDelete()

    /**
     * Generates the built-in delete method.
     */
    function _generateDelete()
    {
        if ($this->_metadata->hasPrimaryKey()) {
            $primaryKey = $this->_metadata->getPrimaryKey();
            $fieldName = array_shift($primaryKey);
            $whereClause = "$fieldName = \$" . Piece_ORM_Inflector::camelize($fieldName, true);
            foreach ($primaryKey as $complexFieldName) {
                $whereClause .= "$complexFieldName = \$" . Piece_ORM_Inflector::camelize($complexFieldName, true);
            }

            $this->_addDelete('DELETE FROM ' . $this->_metadata->getTableName() . " WHERE $whereClause");
        }
    }

    // }}}
    // {{{ _addDelete()

    /**
     * Adds the query for delete() to the mapper source.
     *
     * @param string $query
     */
    function _addDelete($query)
    {
        $this->_methodDefinitions['delete'] = "
    var \$delete = '$query';";
    }

    // }}}
    // {{{ _generateUpdate()

    /**
     * Generates the built-in update method.
     */
    function _generateUpdate()
    {
        if ($this->_metadata->hasPrimaryKey()) {
            $primaryKey = $this->_metadata->getPrimaryKey();
            $fieldName = array_shift($primaryKey);
            $whereClause = "$fieldName = \$" . Piece_ORM_Inflector::camelize($fieldName, true);
            foreach ($primaryKey as $complexFieldName) {
                $whereClause .= "$complexFieldName = \$" . Piece_ORM_Inflector::camelize($complexFieldName, true);
            }

            $fields = array();
            foreach ($this->_metadata->getFieldNames() as $fieldName) {
                if (!$this->_metadata->isAutoIncrement($fieldName)) {
                    if (!$this->_metadata->isPartOfPrimaryKey($fieldName)) {
                        $fields[] = "$fieldName = \$" . Piece_ORM_Inflector::camelize($fieldName, true);
                    }
                }
            }

            $this->_addUpdate('UPDATE ' . $this->_metadata->getTableName() . ' SET ' . implode(", ", $fields) . " WHERE $whereClause");
        }
    }

    // }}}
    // {{{ _addUpdate()

    /**
     * Adds the query for update() to the mapper source.
     *
     * @param string $query
     */
    function _addUpdate($query)
    {
        $this->_methodDefinitions['update'] = "
    var \$update = '$query';";
    }

    /**#@-*/

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: iso-8859-1
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * indent-tabs-mode: nil
 * End:
 */
?>
