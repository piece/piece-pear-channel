<?php echo "$foo\n" ?>
