<?php echo $__example->render() ?>
