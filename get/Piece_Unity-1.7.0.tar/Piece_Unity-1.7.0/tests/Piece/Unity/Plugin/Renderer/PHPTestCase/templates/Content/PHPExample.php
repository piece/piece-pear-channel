This is a test for rendering dynamic pages.
<?php echo $content ?>
