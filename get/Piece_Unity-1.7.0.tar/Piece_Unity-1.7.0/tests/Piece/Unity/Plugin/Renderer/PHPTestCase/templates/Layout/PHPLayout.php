<html>
  <body>
    <h1><?php echo $bar ?></h1>
    <?php echo $__content ?>
  </body>
</html>
