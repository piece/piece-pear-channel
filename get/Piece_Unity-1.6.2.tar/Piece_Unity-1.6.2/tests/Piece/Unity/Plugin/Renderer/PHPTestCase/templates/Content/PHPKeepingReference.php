<?php
$foo->bar = 'baz';
?>
