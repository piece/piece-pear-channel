<div>
  <h2><?php echo $foo ?></h2>
</div>
