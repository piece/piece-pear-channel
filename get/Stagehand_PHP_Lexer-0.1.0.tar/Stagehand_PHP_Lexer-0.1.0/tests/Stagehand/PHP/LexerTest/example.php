<?php
$foo = 'example';
