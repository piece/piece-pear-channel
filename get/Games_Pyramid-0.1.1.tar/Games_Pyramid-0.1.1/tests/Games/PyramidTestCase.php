<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

/**
 * PHP versions 5
 *
 * Copyright (c) 2007 KUBO Atsuhiro <iteman@users.sourceforge.net>,
 * TAKAGI Masahiro <matakagi@gmail.com>,
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    Games_Pyramid
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @author     TAKAGI Masahiro <matakagi@gmail.com>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>, TAKAGI Masahiro <matakagi@gmail.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    SVN: $Id: PyramidTestCase.php 38 2007-03-21 15:04:21Z iteman $
 * @link       http://pear.piece-framework.com/index.php?package=Games_Pyramid
 * @since      File available since Release 0.1.0
 */

set_include_path(dirname(__FILE__) . '/../..' . PATH_SEPARATOR . get_include_path());

require_once 'PHPUnit/Framework.php';
require_once 'Games/Pyramid.php';
require_once 'Games/Pyramid/CardDeck.php';

// {{{ Games_PyramidTestCase

/**
 * @package    Games_Pyramid
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @author     TAKAGI Masahiro <matakagi@gmail.com>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>, TAKAGI Masahiro <matakagi@gmail.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    Release: 0.1.1
 * @link       http://pear.piece-framework.com/index.php?package=Games_Pyramid
 * @since      Class available since Release 0.1.0
 */
class Games_PyramidTestCase extends PHPUnit_Framework_TestCase
{

    // {{{ properties

    /**#@+
     * @access public
     */

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private $_pyramid;

    /**#@-*/

    /**#@+
     * @access public
     */

    public function setUp()
    {
        $cardDeck = array();
        foreach (array(Games_Pyramid_CardDeck::SUIT_HEARTS,
                       Games_Pyramid_CardDeck::SUIT_DIAMONDS,
                       Games_Pyramid_CardDeck::SUIT_CLUBS,
                       Games_Pyramid_CardDeck::SUIT_SPADES) as $suit) {
            for ($i = 1; $i <= 13; ++$i) {
                array_push($cardDeck, new Games_Pyramid_Card($suit, $i));
            }
        }
        Games_Pyramid_CardDeck::$cardDeck = $cardDeck;

        $this->_pyramid = new Games_Pyramid();
    }

    public function tearDown()
    {
        $this->_pyramid = null;
    }

    public function testCreatePyramid()
    {
        $indexInTotal = 0;
        $indexInLevel = 0;
        $indexOfLevel = 0;
        for ($indexOfLevel = 0; $indexOfLevel < 7; ++$indexOfLevel) {
            for ($indexInLevel = 0; $indexInLevel < $indexOfLevel + 1; ++$indexInLevel, ++$indexInTotal) {
            }
        }

        $this->assertEquals($indexInTotal, $this->_pyramid->getCardNumberOfPyramid());
        $this->assertEquals($indexOfLevel, $this->_pyramid->getLevel());
    }

    public function testCardsOfLevelSevenOpened()
    {
        for ($i = 0; $i < 7; ++$i) {
            $this->assertTrue($this->_pyramid->opened(6, $i));
        }
    }

    public function testCardsExceptLevelSevenClosed()
    {
        for ($i = 0; $i < 6; ++$i) {
            for ($j = 0; $j < $i + 1; ++$j) {
                $this->assertFalse($this->_pyramid->opened($i, $j));
            }
        }
    }

    public function testDisplay()
    {
        $pieces = array();
        while ($piece = $this->_pyramid->fetchPiece()) {
            if ($this->_pyramid->increasedInLevel()) {
                $pieces[] = array();
            }

            $index = count($pieces) - 1;
            if (!$piece->opened()) {
                array_push($pieces[$index], '*');
            } else {
                $card = $piece->get();
                array_push($pieces[$index], $card->getNumber());
            }
        }

        for ($i = 0; $i < 7; ++$i) {
            $this->assertEquals($i + 1, count($pieces[$i]));

            if ($i < 6) {
                for ($j = 0; $j < $i + 1; ++$j) {
                    $this->assertEquals('*', $pieces[$i][$j]);
                }
            } elseif ($i == 6) {
                for ($j = 0; $j < $i + 1; ++$j) {
                    $this->assertType('integer', $pieces[$i][$j]);
                }
            }
        }
    }

    public function testRemoveCard()
    {
        $this->_pyramid->removeCard(6, 5);
        $piece = $this->_pyramid->getPiece(6, 5);

        $this->assertTrue($piece->wasRemoved());
    }

    public function testRemoveCardFailure()
    {
        try {
            $this->_pyramid->removeCard(6, 6);
        } catch (Exception $e) {
            return;
        }

        $this->fail('A test failed.');
    }

    public function testRemoveTwoCard()
    {
        $this->_pyramid->removeTwoCards(6, 4, 6, 6);
        $piece1 = $this->_pyramid->getPiece(6, 4);
        $piece2 = $this->_pyramid->getPiece(6, 6);

        $this->assertTrue($piece1->wasRemoved());
        $this->assertTrue($piece2->wasRemoved());
    }

    public function testOpenParentCard()
    {
        $piece1 = $this->_pyramid->getPiece(5, 4);
        $piece2 = $this->_pyramid->getPiece(5, 5);

        $this->assertFalse($piece1->opened());
        $this->assertFalse($piece2->opened());

        $this->_pyramid->removeCard(6, 5);
        $this->_pyramid->removeTwoCards(6, 4, 6, 6);

        $this->assertTrue($piece1->opened());
        $this->assertTrue($piece2->opened());
    }

    public function testDrawCard()
    {
        $card = $this->_pyramid->drawCard();

        $this->assertType('Games_Pyramid_Card', $card);
    }

    public function testExposeCard()
    {
        $card = $this->_pyramid->drawCard();

        $this->assertFalse($this->_pyramid->hasExposedCards());

        $this->_pyramid->exposeCard($card);

        $this->assertEquals($card, $this->_pyramid->getTopExposedCard());
        $this->assertTrue($this->_pyramid->hasExposedCards());
    }

    public function testRemoveCardWithHands()
    {
        $this->_pyramid->removeCard(6, 5);
        $this->_pyramid->removeTwoCards(6, 4, 6, 6);
        $this->_pyramid->removeTwoCards(5, 4, 5, 5);
        $card = $this->_pyramid->drawCard();

        $this->_pyramid->removeCardWithHands(6, 3, $card);

        $piece = $this->_pyramid->getPiece(6, 3);

        $this->assertTrue($piece->wasRemoved());
    }

    public function testRemoveCardWithTopExposed()
    {
        Games_Pyramid_CardDeck::$cardDeck = unserialize('a:52:{i:0;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:1;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:2;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:3;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:4;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:5;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:6;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:7;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:8;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:9;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:10;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:11;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:12;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:13;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:14;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:15;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:16;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}i:17;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:18;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:19;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:20;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:21;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:22;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:23;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:24;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:25;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:26;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:27;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:28;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:29;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:30;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}i:31;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:32;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:33;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:34;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:35;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:36;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:37;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:38;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:39;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:40;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}i:41;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:42;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:43;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:44;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:45;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:46;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:47;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:48;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:49;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:50;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:51;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}}');

        $pyramid = new Games_Pyramid();
        $pyramid->removeCard(6, 0);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 2, $card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 1, $card);
        $pyramid->removeCardWithTopExposed(5, 1);
        $piece = $pyramid->getPiece(5, 1);

        $this->assertTrue($piece->wasRemoved());
        $this->assertEquals(11, $pyramid->getTopExposedCard()->getNumber());
    }

    public function testGameOverByWin()
    {
        $this->_pyramid->removeCard(6, 5);
        $this->_pyramid->removeTwoCards(6, 4, 6, 6);
        $this->_pyramid->removeTwoCards(5, 4, 5, 5);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(6, 3, $card);
        $this->_pyramid->removeTwoCards(5, 3, 6, 0);
        $this->_pyramid->removeCard(4, 3);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(6, 2, $card);
        $this->_pyramid->removeTwoCards(5, 2, 6, 1);
        $this->_pyramid->removeTwoCards(4, 2, 4, 4);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(3, 3, $card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(3, 2, $card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(2, 2, $card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(5, 1, $card);
        $this->_pyramid->removeTwoCards(4, 1, 5, 0);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(4, 0, $card);
        $this->_pyramid->removeTwoCards(3, 0, 3, 1);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->exposeCard($card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(2, 1, $card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(2, 0, $card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(1, 1, $card);
        $card = $this->_pyramid->drawCard();
        $this->_pyramid->removeCardWithHands(1, 0, $card);
        $this->_pyramid->removeCard(0, 0);

        $this->assertTrue($this->_pyramid->isGameOver());
        $this->assertTrue($this->_pyramid->won());
    }

    public function testGameOverByLoss()
    {
        Games_Pyramid_CardDeck::$cardDeck = unserialize('a:52:{i:0;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:1;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:2;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:3;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:4;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:5;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:6;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:7;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:8;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:9;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:10;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:11;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:12;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:13;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:14;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:15;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:7;s:27:" Games_Pyramid_Card _opened";b:0;}i:16;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}i:17;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:18;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:19;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:20;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:21;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:22;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:23;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:2;s:27:" Games_Pyramid_Card _opened";b:0;}i:24;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:25;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:26;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:27;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:28;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:29;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:30;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}i:31;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:32;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:33;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:34;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:35;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:36;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:4;s:27:" Games_Pyramid_Card _opened";b:0;}i:37;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:9;s:27:" Games_Pyramid_Card _opened";b:0;}i:38;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:39;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:6;s:27:" Games_Pyramid_Card _opened";b:0;}i:40;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}i:41;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:1;s:27:" Games_Pyramid_Card _opened";b:0;}i:42;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:11;s:27:" Games_Pyramid_Card _opened";b:0;}i:43;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:12;s:27:" Games_Pyramid_Card _opened";b:0;}i:44;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:45;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:8;s:27:" Games_Pyramid_Card _opened";b:0;}i:46;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:47;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:48;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:4;s:27:" Games_Pyramid_Card _number";i:10;s:27:" Games_Pyramid_Card _opened";b:0;}i:49;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:1;s:27:" Games_Pyramid_Card _number";i:3;s:27:" Games_Pyramid_Card _opened";b:0;}i:50;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:3;s:27:" Games_Pyramid_Card _number";i:5;s:27:" Games_Pyramid_Card _opened";b:0;}i:51;O:18:"Games_Pyramid_Card":3:{s:25:" Games_Pyramid_Card _suit";i:2;s:27:" Games_Pyramid_Card _number";i:13;s:27:" Games_Pyramid_Card _opened";b:0;}}');

        $pyramid = new Games_Pyramid();
        $pyramid->removeCard(6, 0);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 2, $card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 1, $card);
        $pyramid->removeCardWithTopExposed(5, 1);
        $pyramid->removeTwoCards(5, 0, 6, 6);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 3, $card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(4, 0, $card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 5, $card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(6, 4, $card);
        $pyramid->removeTwoCards(5, 2, 5, 4);
        $pyramid->removeCard(4, 1);
        $pyramid->removeCardWithTopExposed(5, 3);
        $pyramid->removeCardWithTopExposed(4, 2);
        $pyramid->removeTwoCards(3, 0, 3, 1);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(2, 0, $card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->removeCardWithHands(4, 3, $card);
        $pyramid->removeTwoCards(3, 2, 5, 5);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);
        $card = $pyramid->drawCard();
        $pyramid->exposeCard($card);

        $this->assertNull($pyramid->drawCard());
        $this->assertTrue($pyramid->isGameOver());
        $this->assertFalse($pyramid->won());
    }

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    /**#@-*/

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: utf-8
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * indent-tabs-mode: nil
 * End:
 */
?>
