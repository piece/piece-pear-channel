<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

/**
 * PHP versions 5
 *
 * Copyright (c) 2007 KUBO Atsuhiro <iteman@users.sourceforge.net>,
 * TAKAGI Masahiro <matakagi@gmail.com>,
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    Games_Pyramid
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @author     TAKAGI Masahiro <matakagi@gmail.com>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>, TAKAGI Masahiro <matakagi@gmail.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    SVN: $Id: CardDeck.php 38 2007-03-21 15:04:21Z iteman $
 * @link       http://pear.piece-framework.com/index.php?package=Games_Pyramid
 * @since      File available since Release 0.1.0
 */

require_once 'Games/Pyramid/Card.php';

// {{{ Games_Pyramid_CardDeck

/**
 * @package    Games_Pyramid
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @author     TAKAGI Masahiro <matakagi@gmail.com>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>, TAKAGI Masahiro <matakagi@gmail.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    Release: 0.1.1
 * @link       http://pear.piece-framework.com/index.php?package=Games_Pyramid
 * @since      Class available since Release 0.1.0
 */
class Games_Pyramid_CardDeck
{

    // {{{ constants

    const SUIT_HEARTS   = 1;
    const SUIT_DIAMONDS = 2;
    const SUIT_CLUBS    = 3;
    const SUIT_SPADES   = 4;

    // }}}
    // {{{ properties

    /**#@+
     * @access public
     */

    public static $cardDeck;

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private $_cardDeck = array();

    /**#@-*/

    public function __construct()
    {
        if (is_null(self::$cardDeck)) {
            foreach (array(self::SUIT_HEARTS,
                           self::SUIT_DIAMONDS,
                           self::SUIT_CLUBS,
                           self::SUIT_SPADES) as $suit) {
                for ($i = 1; $i <= 13; ++$i) {
                    array_push($this->_cardDeck, new Games_Pyramid_Card($suit, $i));
                }
            }

            shuffle($this->_cardDeck);
        } else {
            $this->_cardDeck = self::$cardDeck;
        }
    }

    public function count()
    {
        return count($this->_cardDeck);
    }

    public function draw()
    {
        return array_pop($this->_cardDeck);
    }

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    /**#@-*/

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: utf-8
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * indent-tabs-mode: nil
 * End:
 */
?>
