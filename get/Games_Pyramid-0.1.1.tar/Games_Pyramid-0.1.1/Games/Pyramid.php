<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

/**
 * PHP versions 5
 *
 * Copyright (c) 2007 KUBO Atsuhiro <iteman@users.sourceforge.net>,
 * TAKAGI Masahiro <matakagi@gmail.com>,
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    Games_Pyramid
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @author     TAKAGI Masahiro <matakagi@gmail.com>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>, TAKAGI Masahiro <matakagi@gmail.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    SVN: $Id: Pyramid.php 38 2007-03-21 15:04:21Z iteman $
 * @link       http://pear.piece-framework.com/index.php?package=Games_Pyramid
 * @since      File available since Release 0.1.0
 */

require_once 'Games/Pyramid/Piece.php';
require_once 'Games/Pyramid/CardDeck.php';

// {{{ Games_Pyramid

/**
 * @package    Games_Pyramid
 * @author     KUBO Atsuhiro <iteman@users.sourceforge.net>
 * @author     TAKAGI Masahiro <matakagi@gmail.com>
 * @copyright  2007 KUBO Atsuhiro <iteman@users.sourceforge.net>, TAKAGI Masahiro <matakagi@gmail.com>
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    Release: 0.1.1
 * @link       http://pear.piece-framework.com/index.php?package=Games_Pyramid
 * @since      Class available since Release 0.1.0
 */
class Games_Pyramid
{

    // {{{ properties

    /**#@+
     * @access public
     */

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private $_pyramid = array();
    private $_pyramidLevel;
    private $_currentIndexForFetchPiece = 0;
    private $_cardDeck;
    private $_exposedCards = array();

    /**#@-*/

    /**#@+
     * @access public
     */

    public function __construct()
    {
        $this->_cardDeck = new Games_Pyramid_CardDeck();

        $indexInTotal = 0;
        $indexInLevel = 0;
        $indexOfLevel = 0;
        for ($indexOfLevel = 0; $indexOfLevel < 7; ++$indexOfLevel) {
            for ($indexInLevel = 0; $indexInLevel < $indexOfLevel + 1; ++$indexInLevel, ++$indexInTotal) {
                if ($indexInLevel == 0) {
                    $leftParent = null;
                } else {
                    $leftParent = $this->_pyramid[$indexInTotal - $indexOfLevel - 1];
                }

                if ($indexInLevel == $indexOfLevel) {
                    $rightParent = null;
                } else {
                    $rightParent = $this->_pyramid[$indexInTotal - $indexOfLevel];
                }

                if ($indexOfLevel < 6) {
                    $piece = new Games_Pyramid_Piece($this->_cardDeck->draw(), $leftParent, $rightParent);
                } else {
                    $card = $this->_cardDeck->draw();
                    $card->open();
                    $piece = new Games_Pyramid_Piece($card, $leftParent, $rightParent);

                }

                array_push($this->_pyramid, $piece);
            }
        }

        $this->_pyramidLevel = $indexOfLevel;
    }

    public function getCardNumberOfPyramid()
    {
        return count($this->_pyramid);
    }

    public function getLevel()
    {
        return $this->_pyramidLevel;
    }

    public function opened($indexOfLevel, $indexInLevel)
    {
        return $this->_pyramid[ $this->_findIndexOfPiece($indexOfLevel, $indexInLevel) ]->opened();
    }

    public function fetchPiece()
    {
        if ($this->_currentIndexForFetchPiece < $this->getCardNumberOfPyramid()) {
            $piece = $this->_pyramid[$this->_currentIndexForFetchPiece];
            ++$this->_currentIndexForFetchPiece;
            return $piece;
        }

        $this->_currentIndexForFetchPiece = 0;
        return false;
    }

    public function increasedInLevel()
    {
        return $this->_isFirstIndexInLevel($this->_currentIndexForFetchPiece - 1);
    }

    public function removeCard($indexOfLevel, $indexInLevel)
    {
        $piece = $this->_pyramid[ $this->_findIndexOfPiece($indexOfLevel, $indexInLevel) ];
        $card = $piece->get();
        if ($card->getNumber() != 13) {
            throw new Exception('13以外のカードは単独では取り除けません。');
        }

        $piece->remove();
    }

    public function getPiece($indexOfLevel, $indexInLevel)
    {
        return $this->_pyramid[ $this->_findIndexOfPiece($indexOfLevel, $indexInLevel) ];
    }

    public function removeTwoCards($firstIndexOfLevel, $firstIndexInLevel, $secondIndexOfLevel, $secondIndexInLevel)
    {
        $piece1 = $this->_pyramid[ $this->_findIndexOfPiece($firstIndexOfLevel, $firstIndexInLevel) ];
        $piece2 = $this->_pyramid[ $this->_findIndexOfPiece($secondIndexOfLevel, $secondIndexInLevel) ];
        $card1 = $piece1->get();
        $card2 = $piece2->get();
        if ($card1->getNumber() + $card2->getNumber() != 13) {
            throw new Exception('2つのカードの合計は13でなければいけません。');
        }

        $piece1->remove();
        $piece2->remove();
    }

    public function drawCard()
    {
        return $this->_cardDeck->draw();
    }

    public function exposeCard($card)
    {
        $this->_exposedCards[] = $card;
    }

    public function getTopExposedCard()
    {
        return $this->_exposedCards[count($this->_exposedCards) - 1];
    }

    public function removeCardWithHands($indexOfLevel, $indexInLevel, $cardFromHands)
    {
        $piece = $this->_pyramid[ $this->_findIndexOfPiece($indexOfLevel, $indexInLevel) ];
        $card = $piece->get();
        if ($card->getNumber() + $cardFromHands->getNumber() != 13) {
            throw new Exception('2つのカードの合計は13でなければいけません。');
        }

        $piece->remove();
    }

    public function removeCardWithTopExposed($indexOfLevel, $indexInLevel)
    {
        $piece = $this->_pyramid[ $this->_findIndexOfPiece($indexOfLevel, $indexInLevel) ];
        $card = $piece->get();
        if ($card->getNumber() + $this->getTopExposedCard()->getNumber() != 13) {
            throw new Exception('2つのカードの合計は13でなければいけません。');
        }

        $piece->remove();
        array_pop($this->_exposedCards);
    }

    public function hasExposedCards()
    {
        return (boolean)count($this->_exposedCards);
    }

    public function isGameOver()
    {
        if (!$this->won()) {
            return (boolean)!$this->_cardDeck->count();
        } else {
            return true;
        }
    }

    public function won()
    {
        $piece = $this->_pyramid[ $this->_findIndexOfPiece(0, 0) ];
        return $piece->wasRemoved();
    }

    private function _isFirstIndexInLevel($index)
    {
        $i = 0;
        while ($index - $i >= 0) {
            $index -= $i;
            ++$i;
        }

        if ($index) {
            return false;
        } else {
            return true;
        }
    }

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private function _findIndexOfPiece($indexOfLevel, $indexInLevel)
    {
        return (pow($indexOfLevel, 2) + $indexOfLevel) / 2 + $indexInLevel;
    }

    /**#@-*/

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: utf-8
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * indent-tabs-mode: nil
 * End:
 */
?>
