<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

/**
 * PHP version 5
 *
 * Copyright (c) 2008 ITEMAN, Inc., All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    Games_Couple
 * @copyright  2008 ITEMAN, Inc.
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    SVN: $Id: Couple.php 58 2008-10-28 08:08:36Z iteman $
 * @since      File available since Release 1.0.0
 */

require_once 'Games/Couple/CardDeck.php';
require_once 'Games/Couple/SameRankAndNotAdjacentPairException.php';
require_once 'Games/Couple/NotSameRankAndAdjacentPairException.php';
require_once 'Games/Couple/NotSameRankAndNotAdjacentPairException.php';

// {{{ Games_Couple

/**
 * @package    Games_Couple
 * @copyright  2008 ITEMAN, Inc.
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    Release: 1.0.0
 * @since      Class available since Release 1.0.0
 */
class Games_Couple
{

    // {{{ properties

    /**#@+
     * @access public
     */

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private $_cardDeck;
    private $_lastCard;
    private $_layout = array();

    /**#@-*/

    /**#@+
     * @access public
     */

    public function __construct()
    {
        $this->_cardDeck = new Games_Couple_CardDeck();
    }

    public function draw()
    {
        $card = $this->_cardDeck->draw();
        $this->_layout[] = $card;
        $this->_lastCard = $card;

        return $card;
    }

    public function viewLastCard()
    {
        return $this->_lastCard;
    }

    public function view($row, $col)
    {
        return @$this->_layout[ $this->_calcIndex($row, $col) ];
    }

    public function setCardDeck($cardDeck)
    {
        $this->_cardDeck = $cardDeck;
    }

    public function remove($firstRow, $firstCol, $secondRow, $secondCol)
    {
        if ($this->_areSameRank($firstRow, $firstCol, $secondRow, $secondCol)) {
            if (!$this->_areAdjacent($firstRow, $firstCol, $secondRow, $secondCol)) {
                throw new Games_Couple_SameRankAndNotAdjacentPairException();
            }
        } else {
            if ($this->_areAdjacent($firstRow, $firstCol, $secondRow, $secondCol)) {
                throw new Games_Couple_NotSameRankAndAdjacentPairException();
            } else {
                throw new Games_Couple_NotSameRankAndNotAdjacentPairException();
            }
        }

        $this->_removeCards($firstRow, $firstCol, $secondRow, $secondCol);
    }

    public function isGameOver()
    {
        return is_null($this->view(0, 0));
    }

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private function _calcIndex($row, $col)
    {
        return $row * 4 + $col;
    }

    private function _areSameRank($firstRow, $firstCol, $secondRow, $secondCol)
    {
        return $this->view($firstRow, $firstCol)->rank == $this->view($secondRow, $secondCol)->rank;
    }

    private function _areAdjacentHorizontally($firstRow, $firstCol, $secondRow, $secondCol)
    {
        return $firstRow == $secondRow && abs($firstCol - $secondCol) == 1;
    }

    private function _areAdjacentVertically($firstRow, $firstCol, $secondRow, $secondCol)
    {
        return abs($firstRow - $secondRow) == 1 && $firstCol == $secondCol;
    }

    private function _areAdjacentDiagonally($firstRow, $firstCol, $secondRow, $secondCol)
    {
        return abs($firstRow - $secondRow) == 1
            && (abs($this->_calcIndex($firstRow, $firstCol) - $this->_calcIndex($secondRow, $secondCol)) == 3
                || abs($this->_calcIndex($firstRow, $firstCol) - $this->_calcIndex($secondRow, $secondCol)) == 5);
    }

    private function _areAdjacent($firstRow, $firstCol, $secondRow, $secondCol)
    {
        return $this->_areAdjacentHorizontally($firstRow, $firstCol, $secondRow, $secondCol)
            || $this->_areAdjacentVertically($firstRow, $firstCol, $secondRow, $secondCol)
            || $this->_areAdjacentDiagonally($firstRow, $firstCol, $secondRow, $secondCol);
    }

    private function _removeCards($firstRow, $firstCol, $secondRow, $secondCol)
    {
        array_splice($this->_layout, $this->_calcIndex($firstRow, $firstCol), 1);
        array_splice($this->_layout, $this->_calcIndex($secondRow, $secondCol) - 1, 1);
    }

    /**#@-*/

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: iso-8859-1
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * indent-tabs-mode: nil
 * End:
 */
