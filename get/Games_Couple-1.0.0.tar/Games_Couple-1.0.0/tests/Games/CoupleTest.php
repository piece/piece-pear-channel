<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

/**
 * PHP version 5
 *
 * Copyright (c) 2008 ITEMAN, Inc., All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package    Games_Couple
 * @copyright  2008 ITEMAN, Inc.
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    SVN: $Id: CoupleTest.php 58 2008-10-28 08:08:36Z iteman $
 * @since      File available since Release 1.0.0
 */

require_once 'PHPUnit/Framework.php';
require_once 'Games/Couple.php';
require_once 'Games/Couple/Suit.php';
require_once 'Games/Couple/CardDeck.php';
require_once 'Games/Couple/Card.php';
require_once 'Games/Couple/SameRankAndNotAdjacentPairException.php';
require_once 'Games/Couple/NotSameRankAndAdjacentPairException.php';
require_once 'Games/Couple/NotSameRankAndNotAdjacentPairException.php';

// {{{ Games_CoupleTest

/**
 * Some tests for Games_Couple.
 *
 * @package    Games_Couple
 * @copyright  2008 ITEMAN, Inc.
 * @license    http://www.opensource.org/licenses/bsd-license.php  BSD License (revised)
 * @version    Release: 1.0.0
 * @since      Class available since Release 1.0.0
 */
class Games_CoupleTest extends PHPUnit_Framework_TestCase
{

    // {{{ properties

    /**#@+
     * @access public
     */

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    private $_suits = array(Games_Couple_Suit::SPADES,
                            Games_Couple_Suit::HEARTS,
                            Games_Couple_Suit::DIAMONDS,
                            Games_Couple_Suit::CLUBS);
    private $_ranks = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13);

    /**#@-*/

    /**#@+
     * @access public
     */

    public function testShouldPutACardAfterDrawingIt()
    {
        $couple = new Games_Couple();
        $couple->draw();
        $lastCard = $couple->viewLastCard();
        $this->assertContains($lastCard->suit, $this->_suits);
        $this->assertContains($lastCard->rank, $this->_ranks);
    }

    public function testShouldPlaceCardsProperly()
    {
        $couple = new Games_Couple();
        $couple->draw();
        $lastCard = $couple->viewLastCard();
        $this->assertContains($lastCard->suit, $this->_suits);
        $this->assertContains($lastCard->rank, $this->_ranks);
        $card = $couple->view(0, 0);
        $this->assertContains($card->suit, $this->_suits);
        $this->assertContains($card->rank, $this->_ranks);
        $this->assertSame($lastCard, $card);

        $couple->draw();
        $lastCard = $couple->viewLastCard();
        $this->assertContains($lastCard->suit, $this->_suits);
        $this->assertContains($lastCard->rank, $this->_ranks);
        $card = $couple->view(0, 1);
        $this->assertContains($card->suit, $this->_suits);
        $this->assertContains($card->rank, $this->_ranks);
        $this->assertSame($lastCard, $card);

        $couple->draw();
        $lastCard = $couple->viewLastCard();
        $this->assertContains($lastCard->suit, $this->_suits);
        $this->assertContains($lastCard->rank, $this->_ranks);
        $card = $couple->view(0, 2);
        $this->assertContains($card->suit, $this->_suits);
        $this->assertContains($card->rank, $this->_ranks);
        $this->assertSame($lastCard, $card);

        $couple->draw();
        $lastCard = $couple->viewLastCard();
        $this->assertContains($lastCard->suit, $this->_suits);
        $this->assertContains($lastCard->rank, $this->_ranks);
        $card = $couple->view(0, 3);
        $this->assertContains($card->suit, $this->_suits);
        $this->assertContains($card->rank, $this->_ranks);
        $this->assertSame($lastCard, $card);

        $couple->draw();
        $lastCard = $couple->viewLastCard();
        $this->assertContains($lastCard->suit, $this->_suits);
        $this->assertContains($lastCard->rank, $this->_ranks);
        $card = $couple->view(1, 0);
        $this->assertContains($card->suit, $this->_suits);
        $this->assertContains($card->rank, $this->_ranks);
        $this->assertSame($lastCard, $card);
     }

    public function testShouldAllowToRemoveCardsIfThoseMakeUpPairHorizontally()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::HEARTS, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 2));
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        $card1 = $couple->draw();
        $card2 = $couple->draw();
        $card3 = $couple->draw();

        $couple->remove(0, 0, 0, 1);

        $this->assertSame($card3, $couple->view(0, 0), 1);
        $this->assertNull($couple->view(0, 1), 2);
        $this->assertNull($couple->view(0, 2), 3);
    }

    public function testShouldAllowToRemoveCardsIfThoseMakeUpPairVertically()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 2));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 3));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 4));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::HEARTS, 1));
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        $card1 = $couple->draw();
        $card2 = $couple->draw();
        $card3 = $couple->draw();
        $card4 = $couple->draw();
        $card5 = $couple->draw();

        $couple->remove(0, 0, 1, 0);

        $this->assertSame($card2, $couple->view(0, 0));
        $this->assertSame($card3, $couple->view(0, 1));
        $this->assertSame($card4, $couple->view(0, 2));
        $this->assertNull($couple->view(0, 3));
        $this->assertNull($couple->view(1, 0));
    }

    public function testShouldAllowToRemoveCardsIfThoseMakeUpPairDiagonally()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 2));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 3));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 4));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::HEARTS, 2));
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        $card1 = $couple->draw();
        $card2 = $couple->draw();
        $card3 = $couple->draw();
        $card4 = $couple->draw();
        $card5 = $couple->draw();

        $couple->remove(0, 1, 1, 0);

        $this->assertSame($card1, $couple->view(0, 0));
        $this->assertSame($card3, $couple->view(0, 1));
        $this->assertSame($card4, $couple->view(0, 2));
        $this->assertNull($couple->view(0, 3));
        $this->assertNull($couple->view(1, 0));
    }

    /**
     * @expectedException Games_Couple_SameRankAndNotAdjacentPairException
     */
    public function testShouldRaiseAnExceptionWhenRemovingCardsThatMakeUpSameRankAndNotAdjacentPair()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 2));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::HEARTS, 1));
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        $card1 = $couple->draw();
        $card2 = $couple->draw();
        $card3 = $couple->draw();

        $couple->remove(0, 0, 0, 2);

        $this->assertSame($card1, $couple->view(0, 0));
        $this->assertSame($card2, $couple->view(0, 1));
        $this->assertSame($card3, $couple->view(0, 2));
    }

    /**
     * @expectedException Games_Couple_NotSameRankAndAdjacentPairException
     */
    public function testShouldRaiseAnExceptionWhenRemovingCardsThatMakeUpNotSameRankAndAdjacentPair()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 2));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::HEARTS, 1));
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        $card1 = $couple->draw();
        $card2 = $couple->draw();
        $card3 = $couple->draw();

        $couple->remove(0, 0, 0, 1);

        $this->assertSame($card1, $couple->view(0, 0));
        $this->assertSame($card2, $couple->view(0, 1));
        $this->assertSame($card3, $couple->view(0, 2));
    }

    /**
     * @expectedException Games_Couple_NotSameRankAndNotAdjacentPairException
     */
    public function testShouldRaiseAnExceptionWhenRemovingCardsThatMakeUpNotSameRankAndNotAdjacentPair()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 1));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::SPADES, 2));
        $cardDeck->add(new Games_Couple_Card(Games_Couple_Suit::HEARTS, 2));
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        $card1 = $couple->draw();
        $card2 = $couple->draw();
        $card3 = $couple->draw();

        $couple->remove(0, 0, 0, 2);

        $this->assertSame($card1, $couple->view(0, 0));
        $this->assertSame($card2, $couple->view(0, 1));
        $this->assertSame($card3, $couple->view(0, 2));
    }

    public function testShouldNotDrawACardAfter52CardsHaveAlreadyBeenDrawn()
    {
        $couple = new Games_Couple();
        for ($i = 0; $i < 52; ++$i) {
            $this->assertNotNull($couple->draw());
        }

        $this->assertNull($couple->draw());
    }

    public function testShouldBeGameOverWhenRemoving52Cards()
    {
        $cardDeck = new Games_Couple_CardDeck();
        $cardDeck->reset();
        for ($rank = 1; $rank <= 13; ++$rank) {
            foreach (array(Games_Couple_Suit::SPADES,
                           Games_Couple_Suit::HEARTS,
                           Games_Couple_Suit::DIAMONDS,
                           Games_Couple_Suit::CLUBS) as $suit) {
                $cardDeck->add(new Games_Couple_Card($suit, $rank));
            }
        }
        $couple = new Games_Couple();
        $couple->setCardDeck($cardDeck);
        for ($i = 0; $i < 52; ++$i) {
            $couple->draw();
        }

        for ($i = 0; $i < 25; ++$i) {
            $couple->remove(0, 0, 0, 1);
            $this->assertFalse($couple->isGameOver());
        }

        $couple->remove(0, 0, 0, 1);
        $this->assertTrue($couple->isGameOver());
    }

    /**#@-*/

    /**#@+
     * @access protected
     */

    /**#@-*/

    /**#@+
     * @access private
     */

    /**#@-*/

    // }}}
}

// }}}

/*
 * Local Variables:
 * mode: php
 * coding: iso-8859-1
 * tab-width: 4
 * c-basic-offset: 4
 * c-hanging-comment-ender-p: nil
 * indent-tabs-mode: nil
 * End:
 */
